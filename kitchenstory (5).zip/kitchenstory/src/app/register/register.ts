export class Register
{
    constructor(
        public firstName="",
        public lastName="",
        public email='',
        public password=''){}
}